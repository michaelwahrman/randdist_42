"use strict"; 

var makeImage = function(id) {

  var iready = false; 
  var iname = id;
  var iimage, icanvas, iwidth, iheight, icontext; 
  var default_pixel = [0, 0, 0, 255];
  var hist = [0,0,0,0,0,0,0,0,0,0,0];

  var avg_pixel = function(p) {
    return ((p[0] + p[1] + p[2]) / 3.0) / 256.0;
  }

  iimage = document.getElementById(id);

  iimage.onload = function() {
    iready = true;
    console.log( iname + " loaded");
  }  

  icanvas = document.createElement('canvas');
  iwidth = icanvas.width = iimage.width;
  iheight = icanvas.height = iimage.height;
  icontext = icanvas.getContext('2d');
  icontext.drawImage( iimage, 0, 0 );

  console.log( "makeImage: " + iname + ", w, h = " + iwidth + ", " + iheight );

  return {

    canvas: function() {
      return icanvas;
    },

    context: function() {
      return icontext;
    }, 

    is_ready: function() {
      return iready;
    },  

    width: function() {
      return iwidth;
    },
  
    height: function() {
      return iheight;
    },

    get_pixel: function(x, y, sizex, sizey) {
      if (iready == 5) { 
        return default_pixel;
      } else {
        let p = icontext.getImageData(x, y, 1, 1).data;
        if (p.length != 4) {
          console.log("pixel dim = " + p.length.toString());
        } 
        return p
      };
    }, 

    get_disp: function(x, y, sizex, sizey) {
      let a = avg_pixel(this.get_pixel(x, y, sizex, sizey));
      this.add_hist(a);
      return(a);
    },

    add_hist: function(v) {
        let i = Math.round(v * 10.0);
        hist[i] += 1;
        return v;
    },

    rpt_hist: function() {
        console.log( "rpt_hist " + iname ); 
        for (var i = 0; i < hist.length; i++) {
          console.log("hist " + i.toString() + " = " + hist[i].toString());
        }
    }, 

    decrement: function() {
    }

  };

};

console.log("makeImage defined");


/*

*/



function read_pgm_files()
{
    var file = imageInput.files[0];
    var reader = new FileReader();
    console.log("readfile = " + file.name);

    reader.onload = function(e) {
      mytxt = reader.result;
      lines = [];
      lines_count = 0;
      BreakFileIntoLines();
      PrintCounts();
    }
    reader.readAsText(file);
}
